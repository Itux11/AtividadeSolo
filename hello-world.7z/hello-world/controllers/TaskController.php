<?php

include_once 'models/Task.php';

class TaskController {
    private $db;
    private $task;

    public function __construct($db) {
        $this->db = $db;
        $this->task = new Task($db);
    }

    // Método para criar uma nova tarefa
    public function create($tarefa, $prazo) {
        $this->task->tarefa = $tarefa;
        $this->task->prazo = $prazo;

        if($this->task->create()) {
            return "Tarefa criada.";
        } else {
            return "Não foi possível criar tarefa.";
        }
    }

    // Método para obter detalhes de uma tarefa pelo ID
    public function readOne($id) {
        $this->task->id = $id;
        $this->task->readOne();

        if($this->task->tarefa != null) {
            // Cria um array associativo com os detalhes da tarefa
            $task_arr = array(
                "id" => $this->task->id,
                "tarefa" => $this->task->tarefa,
                "prazo" => $this->task->prazo
            );
            return $task_arr;
        } else {
            return "Tarefa não localizada.";
        }
    }

    // Método para atualizar os dados de uma tarefa
    public function update($id, $tarefa, $prazo) {
        $this->task->id = $id;
        $this->task->tarefa = $tarefa;
        $this->task->prazo = $prazo;

        if($this->task->update()) {
            return "Tarefa atualizado.";
        } else {
            return "Não foi possível atualizar a tarefa.";
        }
    }

    // Método para excluir uma tarefa pelo ID
    public function delete($id) {
        $this->task->id = $id;

        if($this->task->delete()) {
            return "Tarefa foi excluída.";
        } else {
            return "Nao foi possível excluir tarefa.";
        }
    }
    public function index() {
        return $this->readAll();
    }
    
    // Método para listar todas as tarefas (exemplo adicional)
    public function readAll() {
        $query = "SELECT id, tarefa, prazo FROM " . $this->task->table_name;
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $tasks;
    }
}
?>